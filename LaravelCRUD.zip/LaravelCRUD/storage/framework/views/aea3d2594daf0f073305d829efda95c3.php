
<?php $__env->startSection('content'); ?>

<div class="col-md-4 m-auto mt-3 p-2 border border-info">
    <h2 class="text-center">Update Student Details</h2>
    <form action="editdata" method="get">
        <div class="mb-2">
            <label for="">Student Name</label>
            <input type="text" value="<?php echo e($studentname); ?>" name="studentname" class="form-control">
        </div>
        <div class="mb-2">
            <label for="">Email</label>
            <input type="text" value="<?php echo e($email); ?>" name="email" class="form-control">
        </div>
        <div class="mb-2">
            <label for="">Technology</label>
            <input type="text" value="<?php echo e($technology); ?>" name="technology" class="form-control">
        </div>
        <div class="mb-2">
            <label for="">City</label>
            <input type="text" value="<?php echo e($city); ?>" name="city" class="form-control">
        </div>
        <input type="hidden" name="id" value="<?php echo e($id); ?>">
        <button type="submit" class="btn btn-dark mt-2">Update</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\php-data\my_work\Laravel\LaravelCRUD\resources\views/update.blade.php ENDPATH**/ ?>